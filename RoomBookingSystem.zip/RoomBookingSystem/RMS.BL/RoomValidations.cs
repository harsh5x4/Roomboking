﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RMS.Entities;
using RMS.Exceptions;
using RMS.DAL;

/// <summary>
/// Description : Business Layer    
/// Employee ID :138319
/// Employee Name : Emil Biju N
/// Date of Creation : 6-Nov-2017
/// </summary>
namespace RMS.BL
{
    public class RoomValidations
    {
        public static bool ValidateBook(book_138319 book)
        {
            bool bookValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (book.bdate != DateTime.Today)
                {
                    message.Append("Booking Date should be current date\n");
                    bookValidated = false;
                }

                if (book.bbook.Trim() == String.Empty)
                {
                    message.Append("Booking by should be provided\n");
                    bookValidated = false;
                }

                //if ((book.bfromdate - book.bdate).Days < 2)
                //{
                //    message.Append("Booking from Date should be after at least  2 days from booking date\n");
                //    bookValidated = false;
                //}
                //else if ((book.bfromdate - book.btodate).Days > 0)
                //{
                //    message.Append("Booking from date should be less than booking to date");
                //    bookValidated = false;
                //}

                if (bookValidated == false)
                    throw new RoomExceptions(message.ToString());
            }
            catch (RoomExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bookValidated;
        }

        public static int AddBooking(book_138319 r)
        {
            int records = 0;

            try
            {
                if (ValidateBook(r))
                {
                    records = RoomOperations.AddBooking(r);
                }
                else
                    throw new RoomExceptions("Please provide valid information");
            }
            catch (RoomExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static List<book_138319> GetAllBookings()
        {
            List<book_138319> bookList = new List<book_138319>();

            try
            {
                bookList = RoomOperations.GetAllBookings();
            }
            catch (RoomExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bookList;
        }

        public static List<room_138319> GetAllBookings1(string location)
        {
            List<room_138319> roomList = null;

            try
            {
                roomList = RoomOperations.GetAllBookings1(location);
            }
            catch (RoomExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return roomList;
        }
    }
}
