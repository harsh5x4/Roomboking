﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RMS.Entities;
using RMS.Exceptions;
using System.Data.Entity;

/// <summary>
/// Description : DAL (Operations) Layer    
/// Employee ID :138319
/// Employee Name : Emil Biju N
/// Date of Creation : 6-Nov-2017
/// </summary>
namespace RMS.DAL
{
    public class RoomOperations
    {
        static RoomEntities context = new RoomEntities();

        public static int AddBooking(book_138319 r)
        {
            int records = 0;

            try
            {
                context.book_138319.Add(r);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static List<book_138319> GetAllBookings()
        {
            List<book_138319> bookList = null;

            try
            {
                bookList = context.book_138319.ToList<book_138319>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bookList;
        }

        public static List<room_138319> GetAllBookings1(string location)
        {
            List<room_138319> roomList = null;

            try
            {
                roomList = (from t in context.room_138319
                           where t.rlocation == location
                           select t).ToList();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return roomList;
        }
    }
}
