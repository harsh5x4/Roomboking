﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using RMS.Entities;
using RMS.Exceptions;
using RMS.BL;

namespace RMS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            
            InitializeComponent();
        }
        

        private void dgRooms_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            dgRooms.DataContext = RoomValidations.GetAllBookings1(((ComboBoxItem)cmbbox.SelectedItem).Content.ToString());
            
            room_138319 roomsel = (room_138319)dgRooms.SelectedItem;
            gridRoom.DataContext = roomsel;
        }

        private void btnBookRoom_Click(object sender, RoutedEventArgs e)
        {
            book_138319 bk = new book_138319();

            bk.rid = Convert.ToInt32(lblRoomID.Content);
            bk.bdate = Convert.ToDateTime(lblbookingdate.Content.ToString());
            bk.btodate = Convert.ToDateTime(lblbookingtodate.Content.ToString());
            bk.bbook = txtbookingby.Text;

            dgBook.DataContext = bk;
        }
    }
}
